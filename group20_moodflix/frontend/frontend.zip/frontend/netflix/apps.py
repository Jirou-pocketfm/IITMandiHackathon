from django.apps import AppConfig


class NetflixConfig(AppConfig):
    name = 'netflix'
